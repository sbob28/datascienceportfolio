export default function compareDistance({ whatUserSaid }) {
  return whatUserSaid + "!";
}